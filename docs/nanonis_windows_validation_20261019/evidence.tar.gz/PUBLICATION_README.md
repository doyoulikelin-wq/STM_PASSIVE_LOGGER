# 发布证据说明

本归档仅包含历史测量、协议回包、数值数组、分析结论和QA数据，以及3张科学图。没有硬件控制脚本、Windows截图、远控会话、控制台日志或运行连接配置。

所有文本副本已经替换本机绝对路径、连接地址、会话标识和claim路径。`<LOCAL_WORKSPACE>`、`<WINDOWS_ROOT>`等是明确占位符，不是可访问路径。claim证据重命名为`.historical.json`，仅用于历史审计。

两份含Windows会话目录的`Util.SessionPathGet`原始响应未发布，以`.REDACTED.json`说明文件替代。说明记录原始字节长度和SHA-256；不能用说明文件伪装、解码或复算该原包。其他已发布原始wire和f32be矩阵保持字节不变。

`archive_index.json`列出除自身外每个成员的SHA-256和长度，并为衍生文本给出源文件哈希、长度及转换类型。QA中的reviewed_live_outcome_sha256始终指审阅时本地原件，不表示已对去标识衍生JSON重新跑完原验收。归档结构保留工作目录内相对路径，方便对应报告与QA证据条目。

本包不包含本地原始分析脚本；原Demo HTML/XLSX仍位于仓库既有的`docs/nanonis_interface_audit_20261019/`，其两个重复解析大表未重复打包。
